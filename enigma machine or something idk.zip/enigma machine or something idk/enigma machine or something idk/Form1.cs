﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace enigma_machine_or_something_idk
{
    public partial class Form1 : Form
    {
        Random random = new Random();
        char[] abc = new char[] { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
        char[] bigabc = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', };
        char[] nums = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
        int passwor = 1;
        string txt;
        string txt2;
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonE_Click(object sender, EventArgs e)
        {
            if (textE.Text == "9+10") { textD.Text = "21"; }
            else if (textE.Text == "69") { textD.Text = "nice"; }
            else if (textE.Text != "")
            {
                txt = "";
                for (int i = 0; i < textE.Text.Length; i++)
                {
                    txt = txt + Convert.ToString(changeDis(Convert.ToChar(textE.Text[i]), (i + 1) * passwor + 1));
                    if (checkRL.Checked == true) { txt = txt + Convert.ToString(abc[random.Next(0, abc.Length)]); }
                }
                textD.Text = txt;
            }
            if (checkAW.Checked == true)
            {
                Clipboard.SetText(textD.Text);
                SendKeys.Send("%{Tab}");
                System.Threading.Thread.Sleep(200);
                SendKeys.Send("^{v}");
                System.Threading.Thread.Sleep(200);
                SendKeys.Send("{Enter}");
            }
        }

        private void buttonD_Click(object sender, EventArgs e)
        {
            if (textD.Text != "")
            {
                if (checkRL.Checked == true)
                {
                    for (int i = 0; i < textD.Text.Length; i++)
                    {
                        if (i % 2 == 0) { txt2 = txt2 + textD.Text[i]; }
                    }
                }
                else { txt2 = textD.Text; }
                txt = "";
                for (int i = txt2.Length; i != 0; i--)
                {
                    txt = Convert.ToString(changeDis(Convert.ToChar(txt2[i - 1]), (i * passwor + 1) * (-1))) + txt;
                }
                textE.Text = txt;
            }
        }

        private char changeDis(char leter, int changerz)
        {
            char letter = leter;
            int changers = changerz;
            if (Array.Exists(abc, element => element == leter) == true)
            {
                while (Array.IndexOf(abc, leter) + changers + 1 > abc.Length)
                {
                    changers = changers - abc.Length;
                }
                while (Array.IndexOf(abc, leter) + changers < 0)
                {
                    changers = changers + abc.Length;
                }
                leter = abc[Array.IndexOf(abc, leter) + changers];
                return leter;
            }
            else if (Array.Exists(bigabc, element => element == leter) == true)
            {
                while (Array.IndexOf(bigabc, leter) + changers + 1 > bigabc.Length)
                {
                    changers = changers - bigabc.Length;
                }
                while (Array.IndexOf(bigabc, leter) + changers < 0)
                {
                    changers = changers + bigabc.Length;
                }
                leter = bigabc[Array.IndexOf(bigabc, leter) + changers];
                return leter;
            }
            else if (Array.Exists(nums, element => element == leter) == true)
            {
                while (Array.IndexOf(nums, leter) + changers + 1 > nums.Length)
                {
                    changers = changers - nums.Length;
                }
                while (Array.IndexOf(nums, leter) + changers < 0)
                {
                    changers = changers + nums.Length;
                }
                leter = nums[Array.IndexOf(nums, leter) + changers];
                return leter;
            }
            else
            {
                return leter;
            }
        }

        private void buttonP_Click(object sender, EventArgs e)
        {
            try { passwor = Convert.ToInt32(textP.Text); } catch { }
        }

        private void buttonCl_Click(object sender, EventArgs e)
        {
            textE.Text = "";
            textD.Text = "";
        }

        private void buttonCo_Click(object sender, EventArgs e)
        {
            try { Clipboard.SetText(textD.Text); } catch { }
        }

        private void buttonGP_Click(object sender, EventArgs e)
        {
            textP.Text = Convert.ToString(random.Next(1, 9999));
        }

        private void buttonT_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Duży górny pasek - Wiadomość nieszyfrowana\n" +
                "Duży dolny pasek - Wiadomość szyfrowana\n" +
                "Encrypt - Zamienia wiadomość na szyfrowaną\n" +
                "Decrypt - Zamienia szyfrowaną na wiadomość\n" +
                "Clear - Usuwa wszystko z dużych pasków\n" +
                "Copy - Kopiuje to co jest w dużym dolnym pasku\n" +
                "Mały pasek - Miejsce na hasło (liczba)\n" +
                "Set pass - Ustawia liczbę w małym pasku jako hasło (ważne)\n" +
                "Gnr pass - Wstawia losową liczbę w mały pasek (nie ustawia jako hasło od razu)\n" +
                "AutoWrite - klika po koleji: alt+tab, ctrl+v i enter\n" +
                "Random letters - wstawia losowe litery w środku zaszyfrowanej wiadomości\n\n" +
                "Zaszyfrowanie wiadomości - Wstaw wiadomość do dużego górnego paska i kliknij Encrypt\n" +
                "Odszyfrowanie wiadomości - Wstaw szyfrowaną wiadomość do dużego dolnego paska i kliknij Decrypt");
        }
    }
}