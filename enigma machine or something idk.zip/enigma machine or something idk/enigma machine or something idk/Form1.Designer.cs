﻿
namespace enigma_machine_or_something_idk
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.buttonE = new System.Windows.Forms.Button();
            this.buttonD = new System.Windows.Forms.Button();
            this.textE = new System.Windows.Forms.TextBox();
            this.textD = new System.Windows.Forms.TextBox();
            this.buttonCl = new System.Windows.Forms.Button();
            this.textP = new System.Windows.Forms.TextBox();
            this.buttonP = new System.Windows.Forms.Button();
            this.buttonCo = new System.Windows.Forms.Button();
            this.buttonGP = new System.Windows.Forms.Button();
            this.checkAW = new System.Windows.Forms.CheckBox();
            this.checkRL = new System.Windows.Forms.CheckBox();
            this.buttonT = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonE
            // 
            this.buttonE.Location = new System.Drawing.Point(313, 12);
            this.buttonE.Name = "buttonE";
            this.buttonE.Size = new System.Drawing.Size(75, 23);
            this.buttonE.TabIndex = 0;
            this.buttonE.Text = "Encrypt";
            this.buttonE.UseVisualStyleBackColor = true;
            this.buttonE.Click += new System.EventHandler(this.buttonE_Click);
            // 
            // buttonD
            // 
            this.buttonD.Location = new System.Drawing.Point(313, 41);
            this.buttonD.Name = "buttonD";
            this.buttonD.Size = new System.Drawing.Size(75, 23);
            this.buttonD.TabIndex = 1;
            this.buttonD.Text = "Decrypt";
            this.buttonD.UseVisualStyleBackColor = true;
            this.buttonD.Click += new System.EventHandler(this.buttonD_Click);
            // 
            // textE
            // 
            this.textE.Location = new System.Drawing.Point(12, 14);
            this.textE.Name = "textE";
            this.textE.Size = new System.Drawing.Size(295, 20);
            this.textE.TabIndex = 2;
            // 
            // textD
            // 
            this.textD.Location = new System.Drawing.Point(12, 43);
            this.textD.Name = "textD";
            this.textD.Size = new System.Drawing.Size(295, 20);
            this.textD.TabIndex = 3;
            // 
            // buttonCl
            // 
            this.buttonCl.Location = new System.Drawing.Point(394, 12);
            this.buttonCl.Name = "buttonCl";
            this.buttonCl.Size = new System.Drawing.Size(75, 23);
            this.buttonCl.TabIndex = 4;
            this.buttonCl.Text = "Clear";
            this.buttonCl.UseVisualStyleBackColor = true;
            this.buttonCl.Click += new System.EventHandler(this.buttonCl_Click);
            // 
            // textP
            // 
            this.textP.Location = new System.Drawing.Point(475, 43);
            this.textP.Name = "textP";
            this.textP.Size = new System.Drawing.Size(75, 20);
            this.textP.TabIndex = 6;
            this.textP.Text = "1";
            // 
            // buttonP
            // 
            this.buttonP.Location = new System.Drawing.Point(475, 12);
            this.buttonP.Name = "buttonP";
            this.buttonP.Size = new System.Drawing.Size(75, 23);
            this.buttonP.TabIndex = 7;
            this.buttonP.Text = "Set pass";
            this.buttonP.UseVisualStyleBackColor = true;
            this.buttonP.Click += new System.EventHandler(this.buttonP_Click);
            // 
            // buttonCo
            // 
            this.buttonCo.Location = new System.Drawing.Point(394, 41);
            this.buttonCo.Name = "buttonCo";
            this.buttonCo.Size = new System.Drawing.Size(75, 23);
            this.buttonCo.TabIndex = 8;
            this.buttonCo.Text = "Copy";
            this.buttonCo.UseVisualStyleBackColor = true;
            this.buttonCo.Click += new System.EventHandler(this.buttonCo_Click);
            // 
            // buttonGP
            // 
            this.buttonGP.Location = new System.Drawing.Point(556, 41);
            this.buttonGP.Name = "buttonGP";
            this.buttonGP.Size = new System.Drawing.Size(75, 23);
            this.buttonGP.TabIndex = 9;
            this.buttonGP.Text = "Gnr pass";
            this.buttonGP.UseVisualStyleBackColor = true;
            this.buttonGP.Click += new System.EventHandler(this.buttonGP_Click);
            // 
            // checkAW
            // 
            this.checkAW.AutoSize = true;
            this.checkAW.Location = new System.Drawing.Point(556, 16);
            this.checkAW.Name = "checkAW";
            this.checkAW.Size = new System.Drawing.Size(73, 17);
            this.checkAW.TabIndex = 10;
            this.checkAW.Text = "AutoWrite";
            this.checkAW.UseVisualStyleBackColor = true;
            // 
            // checkRL
            // 
            this.checkRL.AutoSize = true;
            this.checkRL.Location = new System.Drawing.Point(637, 16);
            this.checkRL.Name = "checkRL";
            this.checkRL.Size = new System.Drawing.Size(97, 17);
            this.checkRL.TabIndex = 11;
            this.checkRL.Text = "Random letters";
            this.checkRL.UseVisualStyleBackColor = true;
            // 
            // buttonT
            // 
            this.buttonT.Location = new System.Drawing.Point(659, 41);
            this.buttonT.Name = "buttonT";
            this.buttonT.Size = new System.Drawing.Size(75, 23);
            this.buttonT.TabIndex = 12;
            this.buttonT.Text = "Tutorial";
            this.buttonT.UseVisualStyleBackColor = true;
            this.buttonT.Click += new System.EventHandler(this.buttonT_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(746, 76);
            this.Controls.Add(this.buttonT);
            this.Controls.Add(this.checkRL);
            this.Controls.Add(this.checkAW);
            this.Controls.Add(this.buttonGP);
            this.Controls.Add(this.buttonCo);
            this.Controls.Add(this.buttonP);
            this.Controls.Add(this.textP);
            this.Controls.Add(this.buttonCl);
            this.Controls.Add(this.textD);
            this.Controls.Add(this.textE);
            this.Controls.Add(this.buttonD);
            this.Controls.Add(this.buttonE);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(2000, 115);
            this.MinimumSize = new System.Drawing.Size(659, 115);
            this.Name = "Form1";
            this.Text = "Encryptor 1.0";
            this.TopMost = true;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonE;
        private System.Windows.Forms.Button buttonD;
        private System.Windows.Forms.TextBox textE;
        private System.Windows.Forms.TextBox textD;
        private System.Windows.Forms.Button buttonCl;
        private System.Windows.Forms.TextBox textP;
        private System.Windows.Forms.Button buttonP;
        private System.Windows.Forms.Button buttonCo;
        private System.Windows.Forms.Button buttonGP;
        private System.Windows.Forms.CheckBox checkAW;
        private System.Windows.Forms.CheckBox checkRL;
        private System.Windows.Forms.Button buttonT;
    }
}

